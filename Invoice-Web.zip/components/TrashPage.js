// components/TrashPage.js

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { styles } from '../styles/globalStyles';
import SvgIcon from './SvgIcon';
import { useInvoicesContext } from '../contexts/InvoicesContext';
import { useClientsContext } from '../contexts/ClientsContext';

const TrashPage = ({ onPageChange }) => {
  const { trashedInvoices, restoreInvoice, permanentlyDeleteAllTrashed: clearInvoices } = useInvoicesContext();
  const { trashedClients, restoreClient, permanentlyDeleteAllTrashed: clearClients } = useClientsContext();

  const [view, setView] = useState('invoices');
  const [selectedItems, setSelectedItems] = useState([]);

  const toggleSelection = (id) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter(item => item !== id));
    } else {
      // CORRECTION DU BUG
      setSelectedItems([...selectedItems, id]);
    }
  };

  const handleRestoreSelected = () => {
    const restoreAction = view === 'invoices' ? restoreInvoice : restoreClient;
    selectedItems.forEach(id => restoreAction(id));
    setSelectedItems([]);
  };

  const handleClearTrash = () => {
    Alert.alert(
      "Vider la corbeille",
      `Êtes-vous sûr de vouloir supprimer définitivement tous les ${view === 'invoices' ? 'factures' : 'clients'} de la corbeille ? Cette action est irréversible.`,
      [
        { text: "Annuler", style: "cancel" },
        { 
          text: "Vider", 
          style: 'destructive',
          onPress: () => {
            if (view === 'invoices') clearInvoices();
            else clearClients();
            setSelectedItems([]);
          }
        }
      ]
    );
  };
  
  const currentData = view === 'invoices' ? trashedInvoices : trashedClients;

  return (
    <View style={styles.page}>
      <View style={styles.pageHeader}>
        <View>
          <Text style={styles.title}>Corbeille</Text>
          <Text style={styles.subtitle}>Gérez les éléments supprimés</Text>
        </View>
        <TouchableOpacity onPress={() => onPageChange('account')}>
          <Text style={styles.link}>Retour au compte</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.trashTabsContainer}>
        <TouchableOpacity 
          style={[styles.tabButton, view === 'invoices' && styles.tabButtonActive]}
          onPress={() => { setView('invoices'); setSelectedItems([]); }}>
          <Text style={[styles.tabText, view === 'invoices' && styles.tabTextActive]}>Factures</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, view === 'clients' && styles.tabButtonActive]}
          onPress={() => { setView('clients'); setSelectedItems([]); }}>
          <Text style={[styles.tabText, view === 'clients' && styles.tabTextActive]}>Clients</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.trashActions}>
        {selectedItems.length > 0 && (
          <TouchableOpacity style={styles.primaryButton} onPress={handleRestoreSelected}>
            <Text style={styles.primaryButtonText}>Restaurer la sélection ({selectedItems.length})</Text>
          </TouchableOpacity>
        )}
        {currentData.length > 0 && (
           <TouchableOpacity style={styles.clearButton} onPress={handleClearTrash}>
            <Text style={styles.clearButtonText}>Vider la corbeille</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView>
        {currentData.length > 0 ? (
          currentData.map(item => {
            const isSelected = selectedItems.includes(item.id);
            return (
              <TouchableOpacity key={item.id} style={[styles.trashCard, isSelected && styles.selectedItemCard]} onPress={() => toggleSelection(item.id)}>
                <View style={styles.trashInfo}>
                  {view === 'invoices' ? (
                    <>
                      <Text style={styles.trashInvoiceNumber}>{item.invoiceNumber || 'Facture sans numéro'}</Text>
                      <Text style={styles.trashClientInfo}>{`Client: ${item.clientName || 'N/A'} - Total: ${(item.total || 0).toFixed(2)} €`}</Text>
                    </>
                  ) : (
                    <>
                      <Text style={styles.trashInvoiceNumber}>{item.name || 'Client sans nom'}</Text>
                      <Text style={styles.trashClientInfo}>{item.email || 'N/A'}</Text>
                    </>
                  )}
                </View>
                <View style={[styles.checkbox, isSelected && styles.checkboxSelected]}>
                  {isSelected && <SvgIcon name="check" size={16} color="white" />}
                </View>
              </TouchableOpacity>
            )
          })
        ) : (
          <View style={styles.emptyState}>
            <SvgIcon name="trash" size={48} color="#9ca3af" />
            <Text style={styles.emptyText}>La corbeille est vide</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default TrashPage;