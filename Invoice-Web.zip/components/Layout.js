import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import SvgIcon from './SvgIcon';

const Layout = ({ children, currentPage, onPageChange, currentUser }) => {
  // On met à jour la liste des boutons de navigation
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'invoices', label: 'Factures', icon: 'invoices' },
    { id: 'clients', label: 'Clients', icon: 'clients' },
    // On ajoute le nouveau bouton "Compte"
    { id: 'account', label: 'Mon Compte', icon: 'user' }
  ];

  return (
    <View style={styles.layout}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.logo}>
            <SvgIcon name="invoices" size={20} color="white" />
          </View>
          <Text style={styles.logoText}>Invoice</Text>
        </View>
        
        <View style={styles.nav}>
          {menuItems.map(item => (
            <TouchableOpacity
              key={item.id}
              style={[
                styles.navButton,
                currentPage === item.id && styles.navButtonActive
              ]}
              onPress={() => onPageChange(item.id)}
            >
              <SvgIcon name={item.icon} size={16} color={currentPage === item.id ? 'white' : '#6b7280'} />
              <Text style={[
                styles.navText,
                currentPage === item.id && styles.navTextActive
              ]}>
                {item.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.headerRight}>
          <Text style={styles.userInfo}>{currentUser?.email}</Text>
          <TouchableOpacity 
            style={styles.primaryButton}
            onPress={() => onPageChange('new-invoice')}
          >
            <SvgIcon name="plus" size={16} color="white" />
            <Text style={styles.primaryButtonText}>Nouvelle facture</Text>
          </TouchableOpacity>
          
          {/* LE BOUTON DÉCONNEXION A ÉTÉ SUPPRIMÉ D'ICI */}
        </View>
      </View>

      <View style={styles.main}>
        {children}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  layout: {
    flex: 1,
    backgroundColor: '#F3F4F6', // Fond général
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    backgroundColor: '#3B82F6',
    padding: 8,
    borderRadius: 6,
  },
  logoText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1f2937',
    marginLeft: 12,
  },
  nav: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
  navButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    marginHorizontal: 4,
    gap: 8,
  },
  navButtonActive: {
    backgroundColor: '#3B82F6',
  },
  navText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6b7280',
  },
  navTextActive: {
    color: 'white',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  userInfo: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  primaryButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  primaryButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
  // L'ancien style 'logoutButton' n'est plus nécessaire
  main: {
    flex: 1,
  },
});

export default Layout;