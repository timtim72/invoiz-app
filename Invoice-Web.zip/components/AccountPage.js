// components/AccountPage.js

import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert, Linking, ScrollView, TextInput, Image } from 'react-native';
import { styles } from '../styles/globalStyles';
import SvgIcon from './SvgIcon';
import { useAuthContext } from '../contexts/AuthContext';
import { useCompanyProfileContext } from '../contexts/CompanyProfileContext';
import * as ImagePicker from 'expo-image-picker';

const AccountPage = ({ onPageChange }) => {
  const { currentUser, sendPasswordResetEmail, logout } = useAuthContext();
  const { profile, updateProfile } = useCompanyProfileContext();

  const [isEditing, setIsEditing] = useState(false);
  const [formState, setFormState] = useState(profile);

  useEffect(() => {
    setFormState(profile);
  }, [profile]);

  const handleInputChange = (field, value) => {
    setFormState({ ...formState, [field]: value });
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.5,
      base64: true,
    });

    if (!result.canceled) {
      const base64Image = `data:image/jpeg;base64,${result.assets[0].base64}`;
      handleInputChange('logo', base64Image);
    }
  };

  const handleSaveProfile = () => {
    updateProfile(formState);
    // 1. LE MESSAGE DE CONFIRMATION
    Alert.alert("Profil sauvegardé", "Vos informations ont été mises à jour avec succès.");
    setIsEditing(false);
  };

  const handleChangePassword = () => {
    Alert.alert(
      "Réinitialiser le mot de passe",
      `Un e-mail de réinitialisation va être envoyé à ${currentUser.email}. Confirmer ?`,
      [
        { text: "Annuler", style: "cancel" },
        { 
          text: "Envoyer", 
          onPress: async () => {
            const success = await sendPasswordResetEmail(currentUser.email);
            if (success) {
              Alert.alert("E-mail envoyé !", "Veuillez consulter votre boîte de réception.");
            } else {
              Alert.alert("Erreur", "L'e-mail n'a pas pu être envoyé.");
            }
          }
        }
      ]
    );
  };
  const handleContact = () => {
    Linking.openURL('mailto:votre.email@support.com?subject=Support App Facturation');
  };

  return (
    <ScrollView style={styles.page} keyboardShouldPersistTaps="handled">
      <View style={styles.pageHeader}>
        <View>
          <Text style={styles.title}>{isEditing ? "Modifier le Profil" : "Mon Compte"}</Text>
          <Text style={styles.subtitle}>{isEditing ? "Mettez à jour vos informations" : "Gérez vos informations et préférences"}</Text>
        </View>
      </View>

      {isEditing ? (
        <View>
          <TouchableOpacity style={[styles.outlineButton, { alignSelf: 'flex-start', marginBottom: 24 }]} onPress={() => setIsEditing(false)}>
            <Text style={styles.outlineButtonText}>← Retour</Text>
          </TouchableOpacity>
          <View style={styles.accountCard}>
            <View style={styles.form}>
              <Text style={styles.label}>Nom de l'entreprise</Text>
              <TextInput style={styles.input} value={formState.name} onChangeText={(text) => handleInputChange('name', text)} />
              <Text style={styles.label}>Adresse</Text>
              <TextInput style={[styles.input, { height: 80, textAlignVertical: 'top' }]} value={formState.address} onChangeText={(text) => handleInputChange('address', text)} multiline />
              <Text style={styles.label}>Logo de l'entreprise</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
                <TouchableOpacity style={styles.outlineButton} onPress={pickImage}>
                  <Text style={styles.outlineButtonText}>Choisir une image</Text>
                </TouchableOpacity>
                {/* 2. L'APERÇU DU LOGO */}
                {formState.logo && (
                  <Image source={{ uri: formState.logo }} style={styles.logoPreview} />
                )}
              </View>
              <TouchableOpacity style={[styles.primaryButton, { marginTop: 20 }]} onPress={handleSaveProfile}>
                <Text style={styles.primaryButtonText}>Enregistrer le profil</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      ) : (
        <View>
          <View style={styles.userInfoHeader}>
            <Text style={styles.userInfoLabel}>Connecté en tant que</Text>
            <Text style={styles.userInfoEmail}>{currentUser?.email}</Text>
          </View>
          <Text style={styles.sectionTitle}>Profil</Text>
          <View style={styles.accountCard}>
            <TouchableOpacity style={styles.accountRow} onPress={() => setIsEditing(true)}>
              <SvgIcon name="edit" size={20} color="#6b7280" />
              <Text style={styles.accountText}>Modifier le profil de l'entreprise</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.sectionTitle}>Gestion du Compte</Text>
          <View style={styles.accountCard}>
            <TouchableOpacity style={styles.accountRow} onPress={handleChangePassword}>
              <SvgIcon name="user" size={20} color="#6b7280" />
              <Text style={styles.accountText}>Changer mon mot de passe</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.sectionTitle}>Données</Text>
          <View style={styles.accountCard}>
            <TouchableOpacity style={styles.accountRow} onPress={() => onPageChange('trash')}>
              <SvgIcon name="trash" size={20} color="#6b7280" />
              <Text style={styles.accountText}>Corbeille</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.sectionTitle}>Support</Text>
          <View style={styles.accountCard}>
            <TouchableOpacity style={styles.accountRow} onPress={handleContact}>
              <SvgIcon name="send" size={20} color="#6b7280" />
              <Text style={styles.accountText}>Contacter le support</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.logoutButton} onPress={logout}>
            <Text style={styles.logoutButtonText}>Déconnexion</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
};

export default AccountPage;