// components/InvoiceNew.js

import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView, FlatList } from 'react-native';
import { styles } from '../styles/globalStyles';
import { useClientsContext } from '../contexts/ClientsContext';
import { useInvoicesContext } from '../contexts/InvoicesContext';

const LineItemCard = ({ item, index, onItemChange, onRemoveItem }) => (
  <View style={styles.itemCard}>
    <TouchableOpacity onPress={() => onRemoveItem(index)} style={styles.deleteButton}><Text style={styles.deleteButtonText}>✕</Text></TouchableOpacity>
    <View style={styles.fieldContainer}><Text style={styles.label}>Description</Text><TextInput style={styles.input} placeholder="Nom du produit ou service" value={item.description} onChangeText={(text) => onItemChange(index, 'description', text)} /></View>
    <View style={{ flexDirection: 'row' }}>
      <View style={[styles.fieldContainer, { flex: 1, marginRight: 8 }]}><Text style={styles.label}>Quantité</Text><TextInput style={styles.input} placeholder="1" value={String(item.quantity)} onChangeText={(text) => onItemChange(index, 'quantity', text)} keyboardType="numeric" /></View>
      <View style={[styles.fieldContainer, { flex: 1.5 }]}><Text style={styles.label}>Prix U. (€)</Text><TextInput style={styles.input} placeholder="150.00" value={String(item.price)} onChangeText={(text) => onItemChange(index, 'price', text)} keyboardType="numeric" /></View>
    </View>
  </View>
);

const InvoiceNew = ({ onPageChange }) => {
  const { clients } = useClientsContext();
  const { addInvoice } = useInvoicesContext();

  // NOUVEL ÉTAT POUR MÉMORISER LA POSITION DU CHAMP DE RECHERCHE
  const [searchBoxPosition, setSearchBoxPosition] = useState({ y: 0, height: 0 });
  
  const [clientName, setClientName] = useState('');
  const [clientSearchQuery, setClientSearchQuery] = useState('');
  const [filteredClients, setFilteredClients] = useState([]);
  const [isClientSelected, setIsClientSelected] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState(`FAC-${Date.now()}`);
  const [lineItems, setLineItems] = useState([{ description: '', quantity: 1, price: 0 }]);
  const [subtotal, setSubtotal] = useState(0);
  const [tax, setTax] = useState(0);
  const [total, setTotal] = useState(0);
  const TVA_RATE = 0.20;

  const handleClientSearch = (query) => {
    setClientSearchQuery(query);
    setIsClientSelected(false);
    if (query) setFilteredClients(clients.filter(c => c.name.toLowerCase().includes(query.toLowerCase())));
    else setFilteredClients([]);
  };

  const handleSelectClient = (client) => {
    setClientName(client.name);
    setClientSearchQuery(client.name);
    setFilteredClients([]);
    setIsClientSelected(true);
  };

  useEffect(() => {
    const currentSubtotal = lineItems.reduce((acc, item) => (acc + (parseFloat(item.quantity) || 0) * (parseFloat(item.price) || 0)), 0);
    const currentTax = currentSubtotal * TVA_RATE;
    const currentTotal = currentSubtotal + currentTax;
    setSubtotal(currentSubtotal); setTax(currentTax); setTotal(currentTotal);
  }, [lineItems]);

  const handleItemChange = (index, field, value) => {
    const newItems = [...lineItems];
    newItems[index][field] = value;
    setLineItems(newItems);
  };
  const handleAddItem = () => setLineItems([...lineItems, { description: '', quantity: 1, price: 0 }]);
  const handleRemoveItem = (index) => { if (lineItems.length > 1) setLineItems(lineItems.filter((_, i) => i !== index)); };
  
  const handleSaveInvoice = () => {
    if (!isClientSelected || !clientName) {
      Alert.alert('Erreur', 'Veuillez sélectionner un client dans la liste.');
      return;
    }
    const newInvoiceData = { clientName, invoiceNumber, lineItems, subtotal, tax, total, status: 'draft', createdAt: new Date().toISOString() };
    addInvoice(newInvoiceData);
    Alert.alert('Succès', 'Facture créée avec succès !');
    onPageChange('invoices');
  };

  return (
    // On utilise une View simple comme conteneur principal
    <View style={styles.page}>
      {/* 1. LA COUCHE DU FOND : LE FORMULAIRE DÉFILABLE */}
      <ScrollView keyboardShouldPersistTaps="handled">
        <View style={styles.pageHeader}>
          <Text style={styles.title}>Nouvelle Facture</Text>
        </View>
        <View style={styles.form}>
          <View style={styles.fieldContainer}>
            <Text style={styles.label}>Numéro de facture</Text>
            <TextInput style={styles.input} value={invoiceNumber} onChangeText={setInvoiceNumber} />
          </View>
          
          <View 
            style={styles.fieldContainer}
            // CETTE LIGNE MESURE LA POSITION DU CHAMP ET LA SAUVEGARDE
            onLayout={(event) => {
              const layout = event.nativeEvent.layout;
              setSearchBoxPosition({ y: layout.y, height: layout.height });
            }}
          >
            <Text style={styles.label}>Rechercher un client</Text>
            <TextInput
              style={styles.input}
              placeholder="Tapez pour rechercher..."
              value={clientSearchQuery}
              onChangeText={handleClientSearch}
            />
          </View>
          
          <Text style={[styles.label, { marginTop: 16, fontSize: 16 }]}>Produits / Services</Text>
          {lineItems.map((item, index) => (
            <LineItemCard key={index} item={item} index={index} onItemChange={handleItemChange} onRemoveItem={handleRemoveItem} />
          ))}

          <TouchableOpacity style={styles.secondaryButton} onPress={handleAddItem}>
            <Text style={styles.secondaryButtonText}>+ Ajouter un produit</Text>
          </TouchableOpacity>
          
          <View style={styles.totalsSection}>
            <View style={styles.totalRow}><Text style={styles.totalText}>Sous-total :</Text><Text style={styles.totalAmount}>{subtotal.toFixed(2)} €</Text></View>
            <View style={styles.totalRow}><Text style={styles.totalText}>TVA ({(TVA_RATE * 100).toFixed(0)}%) :</Text><Text style={styles.totalAmount}>{tax.toFixed(2)} €</Text></View>
            <View style={[styles.totalRow, styles.grandTotalRow]}><Text style={styles.grandTotalText}>TOTAL :</Text><Text style={styles.grandTotalAmount}>{total.toFixed(2)} €</Text></View>
          </View>

          <TouchableOpacity style={styles.primaryButton} onPress={handleSaveInvoice}>
            <Text style={styles.primaryButtonText}>Enregistrer la facture</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* 2. LA COUCHE DU DESSUS : LA LISTE FLOTTANTE */}
      {filteredClients.length > 0 && !isClientSelected && (
        <FlatList
          style={[
            styles.searchResultsContainer,
            // On utilise la position sauvegardée pour se placer parfaitement
            { top: searchBoxPosition.y + searchBoxPosition.height - 30 } 
          ]}
          data={filteredClients}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.searchResultItem} onPress={() => handleSelectClient(item)}>
              <Text>{item.name}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

export default InvoiceNew;