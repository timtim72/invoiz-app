// utils/pdfGenerator.js

import jsPDF from 'jspdf';

// La fonction accepte maintenant le profil de l'entreprise en plus des données de la facture
export const generateInvoicePdf = (invoiceData, companyProfile) => {
  const doc = new jsPDF();

  // 1. DESSINER LE LOGO (s'il existe)
  if (companyProfile.logo) {
    try {
      // jspdf a besoin de connaître le format de l'image (jpeg, png, etc.)
      const imgFormat = companyProfile.logo.split(';')[0].split('/')[1].toUpperCase();
      // On dessine le logo en haut à gauche
      doc.addImage(companyProfile.logo, imgFormat, 15, 15, 30, 30); // Position x, y, largeur, hauteur
    } catch (e) {
      console.error("Erreur lors de l'ajout du logo au PDF:", e);
    }
  }
  
  // 2. Utiliser les informations de l'entreprise du profil
  doc.setFontSize(20);
  doc.text(companyProfile.name || "Nom de l'entreprise", 15, 55); // Décalé vers le bas si le logo est présent
  doc.setFontSize(10);
  doc.text(companyProfile.address || "Adresse de l'entreprise", 15, 60);

  // 3. Dessiner l'en-tête de la facture
  doc.setFontSize(16);
  doc.text(`FACTURE ${invoiceData.invoiceNumber}`, 140, 20);

  // 4. Informations du client
  doc.setFontSize(12);
  doc.text("Client :", 15, 80);
  doc.setFontSize(10);
  doc.text(invoiceData.clientName, 15, 85);

  // 5. Tableau des produits/services
  let yPosition = 110; // Position de départ du tableau abaissée
  doc.setFontSize(12);
  doc.text("Description", 15, yPosition);
  doc.text("Qté", 120, yPosition);
  doc.text("Prix U.", 140, yPosition);
  doc.text("Total", 170, yPosition);
  yPosition += 10;
  doc.setFontSize(10);

  (invoiceData.lineItems || []).forEach(item => {
    doc.text(item.description, 15, yPosition);
    doc.text(String(item.quantity), 120, yPosition);
    doc.text(`${Number(item.price).toFixed(2)} €`, 140, yPosition);
    doc.text(`${(item.quantity * item.price).toFixed(2)} €`, 170, yPosition);
    yPosition += 7;
  });

  // 6. Totaux
  yPosition = Math.max(yPosition, 180); // S'assure que les totaux sont assez bas
  doc.setFontSize(12);
  doc.text(`Sous-total : ${(invoiceData.subtotal || 0).toFixed(2)} €`, 140, yPosition);
  yPosition += 7;
  doc.text(`TVA (20%) : ${(invoiceData.tax || 0).toFixed(2)} €`, 140, yPosition);
  yPosition += 7;
  doc.setFont("helvetica", "bold");
  doc.text(`TOTAL : ${(invoiceData.total || 0).toFixed(2)} €`, 140, yPosition);
  doc.setFont("helvetica", "normal");
  
  // 7. Pied de page
  doc.setFontSize(8);
  doc.text("Merci de votre confiance.", 15, 280);

  // 8. Sauvegarder le fichier
  doc.save(`facture-${invoiceData.invoiceNumber}.pdf`);
};