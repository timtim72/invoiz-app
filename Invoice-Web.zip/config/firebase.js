// config/firebase.js

// On garde juste la configuration
const firebaseConfig = {
  apiKey: "AIzaSyCoADMMElhC6N0-NzEY_tItxcM1z2xPtqI", // Votre clé API
};

// L'URL de base pour l'authentification REST de Firebase
const AUTH_URL = `https://identitytoolkit.googleapis.com/v1/accounts`;

// On exporte des fonctions qui utilisent 'fetch'
export const authAPI = {
  signUp: (email, password) => 
    fetch(`${AUTH_URL}:signUp?key=${firebaseConfig.apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true })
    }),
  
  signIn: (email, password) =>
    fetch(`${AUTH_URL}:signInWithPassword?key=${firebaseConfig.apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true })
    }),
    
  // NOUVELLE FONCTION à ajouter
  sendPasswordResetEmail: (email) =>
    fetch(`${AUTH_URL}:sendOobCode?key=${firebaseConfig.apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requestType: 'PASSWORD_RESET', email: email })
    }),
};