// App.js

import React, { useState } from 'react';
import { View } from 'react-native';
import { styles } from './styles/globalStyles';

import { AuthProvider, useAuthContext } from './contexts/AuthContext';
import { InvoicesProvider } from './contexts/InvoicesContext';
import { ClientsProvider } from './contexts/ClientsContext';
import { CompanyProfileProvider } from './contexts/CompanyProfileContext';

import LoginScreen from './components/LoginScreen';
import RegisterScreen from './components/RegisterScreen';
import Dashboard from './components/Dashboard';
import InvoiceNew from './components/InvoiceNew';
import InvoicesList from './components/InvoicesList';
import ClientsPage from './components/ClientsPage';
import Layout from './components/Layout';
import AccountPage from './components/AccountPage';
import TrashPage from './components/TrashPage';
// NOUVEAU : On importe notre page de détail
import MonthlyInvoicesPage from './components/MonthlyInvoicesPage';

const AppContent = () => {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [authScreen, setAuthScreen] = useState('login');
  // NOUVEL ÉTAT pour garder en mémoire le mois sélectionné
  const [selectedMonthData, setSelectedMonthData] = useState(null);
  
  const { currentUser, login, register } = useAuthContext();

  // NOUVELLE FONCTION pour gérer la navigation vers la page de détail
  const handleViewMonthDetails = (monthData) => {
    setSelectedMonthData(monthData);
    setCurrentPage('monthly-details');
  };

  if (!currentUser) {
    return authScreen === 'login' ? (
      <LoginScreen onLogin={login} onSwitchToRegister={() => setAuthScreen('register')} />
    ) : (
      <RegisterScreen onRegister={register} onSwitchToLogin={() => setAuthScreen('login')} />
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      // On passe la nouvelle fonction au Dashboard
      case 'dashboard': return <Dashboard onPageChange={setCurrentPage} onViewMonthDetails={handleViewMonthDetails} />;
      case 'new-invoice': return <InvoiceNew onPageChange={setCurrentPage} />;
      case 'invoices': return <InvoicesList onPageChange={setCurrentPage} />;
      case 'clients': return <ClientsPage onPageChange={setCurrentPage} />;
      case 'account': return <AccountPage onPageChange={setCurrentPage} />;
      case 'trash': return <TrashPage onPageChange={setCurrentPage} />;
      // On ajoute la route pour la nouvelle page
      case 'monthly-details': return <MonthlyInvoicesPage monthData={selectedMonthData} onPageChange={setCurrentPage} />;
      default: return <Dashboard onPageChange={setCurrentPage} onViewMonthDetails={handleViewMonthDetails} />;
    }
  };

  return (
    <Layout
      currentPage={currentPage}
      onPageChange={setCurrentPage}
      currentUser={currentUser}
    >
      {renderPage()}
    </Layout>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <InvoicesProvider>
        <ClientsProvider>
          <CompanyProfileProvider>
            <View style={styles.container}>
              <AppContent />
            </View>
          </CompanyProfileProvider>
        </ClientsProvider>
      </InvoicesProvider>
    </AuthProvider>
  );
}