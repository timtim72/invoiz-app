// hooks/useCompanyProfile.js

import { useLocalStorage } from './useLocalStorage';

const initialProfile = {
  name: "Votre Nom / Nom de l'entreprise",
  address: "123 Votre Rue, 75000 Votre Ville",
  logo: null, // On stockera le logo en format base64
};

export const useCompanyProfile = () => {
  const [profile, setProfile] = useLocalStorage('companyProfile', initialProfile);

  const updateProfile = (newProfileData) => {
    setProfile(newProfileData);
  };

  return { profile, updateProfile };
};