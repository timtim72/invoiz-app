// hooks/useAuth.js

import { authAPI } from '../config/firebase';
import { useLocalStorage } from './useLocalStorage';

export const useAuth = () => {
  const [currentUser, setCurrentUser] = useLocalStorage('currentUser', null);

  const login = async (email, password) => {
    try {
      const response = await authAPI.signIn(email, password);
      const data = await response.json();
      
      if (data.idToken) {
        const user = { email: data.email, uid: data.localId };
        setCurrentUser(user);
        return true;
      } else {
        console.error("Échec de la connexion:", data.error.message);
        return false;
      }
    } catch (error) {
      console.error("Erreur réseau ou autre:", error);
      return false;
    }
  };

  const register = async (email, password) => {
    try {
      const response = await authAPI.signUp(email, password);
      const data = await response.json();
      
      if (data.idToken) {
        const newUser = { email: data.email, uid: data.localId };
        setCurrentUser(newUser);
        return true;
      } else {
        console.error("Échec de l'inscription:", data.error.message);
        return false;
      }
    } catch (error) {
      console.error("Erreur réseau ou autre:", error);
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
  };
  
  // NOUVELLE FONCTION à ajouter
  const sendPasswordResetEmail = async (email) => {
    try {
      const response = await authAPI.sendPasswordResetEmail(email);
      // Retourne true si la requête a réussi, false sinon
      return response.ok;
    } catch (error) {
      console.error("Erreur lors de l'envoi de l'email de réinitialisation:", error);
      return false;
    }
  };

  return { 
    currentUser, 
    login, 
    register, 
    logout,
    // On l'exporte ici pour que les autres composants puissent l'utiliser
    sendPasswordResetEmail 
  };
};