// hooks/useClients.js

import { useLocalStorage } from './useLocalStorage';

export const useClients = () => {
  const [clients, setClients] = useLocalStorage('clients', []);
  // On s'assure que la clé est bien 'trashedClients'
  const [trashedClients, setTrashedClients] = useLocalStorage('trashedClients', []);

  const addClient = (clientData) => {
    const newClient = {
      id: `CLIENT-${Date.now()}`,
      ...clientData
    };
    setClients(currentClients => [newClient, ...currentClients]);
    return newClient;
  };

  const updateClient = (id, updates) => {
    setClients(currentClients => 
      currentClients.map(client => 
        client.id === id ? { ...client, ...updates } : client
      )
    );
  };

  const deleteClient = (id) => {
    const clientToDelete = clients.find(c => c.id === id);
    if (clientToDelete) {
      setTrashedClients(prev => [clientToDelete, ...prev]);
      setClients(prev => prev.filter(c => c.id !== id));
    }
  };

  const restoreClient = (id) => {
    const clientToRestore = trashedClients.find(c => c.id === id);
    if (clientToRestore) {
      setClients(prev => [clientToRestore, ...prev]);
      setTrashedClients(prev => prev.filter(c => c.id !== id));
    }
  };

  const permanentlyDeleteAllTrashed = () => {
    setTrashedClients([]);
  };

  return { 
    clients, 
    addClient, 
    updateClient, 
    deleteClient,
    trashedClients,
    restoreClient,
    permanentlyDeleteAllTrashed,
  };
};