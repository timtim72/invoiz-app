// hooks/useInvoices.js

import { useLocalStorage } from './useLocalStorage';

export const useInvoices = () => {
  const [invoices, setInvoices] = useLocalStorage('invoices', []);
  // On s'assure que la clé est bien 'trashedInvoices'
  const [trashedInvoices, setTrashedInvoices] = useLocalStorage('trashedInvoices', []);

  const addInvoice = (invoiceData) => {
    const newInvoice = {
      id: 'inv_' + Date.now(),
      ...invoiceData 
    };
    setInvoices(prev => [newInvoice, ...prev]);
    return newInvoice;
  };

  const updateInvoice = (id, updates) => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, ...updates } : inv));
  };

  const deleteInvoice = (id) => {
    const invoiceToDelete = invoices.find(inv => inv.id === id);
    if (invoiceToDelete) {
      setTrashedInvoices(prev => [invoiceToDelete, ...prev]);
      setInvoices(prev => prev.filter(inv => inv.id !== id));
    }
  };
  
  const restoreInvoice = (id) => {
    const invoiceToRestore = trashedInvoices.find(inv => inv.id === id);
    if (invoiceToRestore) {
      setInvoices(prev => [invoiceToRestore, ...prev]);
      setTrashedInvoices(prev => prev.filter(inv => inv.id !== id));
    }
  };

  const permanentlyDeleteAllTrashed = () => {
    setTrashedInvoices([]);
  };

  return { 
    invoices, 
    addInvoice, 
    updateInvoice, 
    deleteInvoice,
    trashedInvoices,
    restoreInvoice,
    permanentlyDeleteAllTrashed,
  };
};